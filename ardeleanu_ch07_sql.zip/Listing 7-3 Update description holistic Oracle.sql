-- Listing 7-3 Update description holistic Oracle
CREATE PROCEDURE Upd_Products_Desc_Holistic
AS
BEGIN
	UPDATE Products
	SET Product_Description = (SELECT 
		CASE WHEN Products.Make_Flag = 1 AND SUBSTR (t.Product_Type_Code, 1, 1) = 'C' 
			THEN 'DESC_' || Products.Product_Code || '_' || t.Product_Type_Code
		 WHEN Products.Make_Flag = 0 AND SUBSTR (t.Product_Type_Code, 1, 1) = 'C' 
			THEN 'DESC_' || Products.Product_Code || '_' || t.Name
		 WHEN Products.Make_Flag = 0 AND SUBSTR (t.Product_Type_Code, 1, 1) <> 'C' 	
		    THEN 'DESC_' || t.Name
		 WHEN Products.Make_Flag = 1 AND SUBSTR (t.Product_Type_Code, 1, 1) <> 'C'   
			THEN 'DESC_' || t.Product_Type_Code
		END		    
	FROM Product_Types t WHERE t.Product_Type_Id = Products.Product_Type_Id);
	
	COMMIT;
END;
/	