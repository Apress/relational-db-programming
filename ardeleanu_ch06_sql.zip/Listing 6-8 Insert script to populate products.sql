-- Listing 6-8 Insert script to populate products
INSERT INTO Product_Types (Product_Type_Id, Product_Type_Code, Name)
VALUES (1, 'C1', 'Product type 01 description');
INSERT INTO Product_Types (Product_Type_Id, Product_Type_Code, Name)
VALUES (2, 'C2', 'Product type 02 description');
INSERT INTO Product_Types (Product_Type_Id, Product_Type_Code, Name)
VALUES (3, 'D3', 'Product type 03 description');

INSERT INTO Products (Product_Id, Name, Product_Code, Make_Flag, Product_Type_Id, Default_Quantity)
VALUES (1, 'Product 01', 'A1', 0, 1, 10);
INSERT INTO Products (Product_Id, Name, Product_Code, Make_Flag, Product_Type_Id, Default_Quantity)
VALUES (2, 'Product 02', 'A2', 1, 2, 20);
INSERT INTO Products (Product_Id, Name, Product_Code, Make_Flag, Product_Type_Id, Default_Quantity)
VALUES (3, 'Product 03', 'A3', 0, 1, 5);
INSERT INTO Products (Product_Id, Name, Product_Code, Make_Flag, Product_Type_Id, Default_Quantity)
VALUES (4, 'Product 04', 'A4', 1, 3, 1);
INSERT INTO Products (Product_Id, Name, Product_Code, Make_Flag, Product_Type_Id, Default_Quantity)
VALUES (5, 'Product 05', 'A5', 0, 1, 9);
INSERT INTO Products (Product_Id, Name, Product_Code, Make_Flag, Product_Type_Id, Default_Quantity)
VALUES (6, 'Product 06', 'A6', 0, 1, 20);
INSERT INTO Products (Product_Id, Name, Product_Code, Make_Flag, Product_Type_Id, Default_Quantity)
VALUES (7, 'Product 07', 'A7', 0, 2, 15);
INSERT INTO Products (Product_Id, Name, Product_Code, Make_Flag, Product_Type_Id, Default_Quantity)
VALUES (8, 'Product 08', 'A8', 1, 3, 6);
INSERT INTO Products (Product_Id, Name, Product_Code, Make_Flag, Product_Type_Id, Default_Quantity)
VALUES (9, 'Product 09', 'A9', 1, 1, 8);
INSERT INTO Products (Product_Id, Name, Product_Code, Make_Flag, Product_Type_Id, Default_Quantity)
VALUES (10, 'Product 10', 'A10', 1, 2, 8);