-- Listing 7-7 Update the design
ALTER TABLE Languages
ADD Language_Table_Name VARCHAR(30);

UPDATE Languages
SET Language_Table_Name = 'English_European_Countries'
WHERE Language_Id = 2;

UPDATE Languages
SET Language_Table_Name = 'French_European_Countries'
WHERE Language_Id = 3;
