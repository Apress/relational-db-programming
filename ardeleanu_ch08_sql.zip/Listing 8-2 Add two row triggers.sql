-- Listing 8-2 Add two row triggers
CREATE TRIGGER English_CL_Id_Tg 
BEFORE INSERT ON English_European_Countries
FOR EACH ROW
DECLARE
BEGIN
	IF :new.English_CL_Id IS NULL THEN
		:new.English_CL_Id := English_CL_Id_Seq.nextval;
	END IF;
END;
/

CREATE TRIGGER French_CL_Id_Tg 
BEFORE INSERT ON French_European_Countries
FOR EACH ROW
DECLARE
BEGIN
	IF :new.French_CL_Id IS NULL THEN
		:new.French_CL_Id := French_CL_Id_Seq.nextval;
	END IF;
END;
/
