-- Listing 5-3 Insert script to populate countries and languages
INSERT INTO Countries (Country_Id, Country_Code, Country_Name, Continent) VALUES (1, 'AR', 'Argentina', 'South America');
INSERT INTO Countries (Country_Id, Country_Code, Country_Name, Continent) VALUES (2, 'AT', 'Austria', 'Europe');
INSERT INTO Countries (Country_Id, Country_Code, Country_Name, Continent) VALUES (3, 'FR', 'France', 'Europe');
INSERT INTO Countries (Country_Id, Country_Code, Country_Name, Continent) VALUES (4, 'MT', 'Malta', 'Europe');
INSERT INTO Countries (Country_Id, Country_Code, Country_Name, Continent) VALUES (5, 'ES', 'Spain', 'Europe'); 	
INSERT INTO Countries (Country_Id, Country_Code, Country_Name, Continent) VALUES (6, 'CH', 'Switzerland', 'Europe');
INSERT INTO Countries (Country_Id, Country_Code, Country_Name, Continent) VALUES (7, 'NL', 'The Netherlands', 'Europe');
INSERT INTO Countries (Country_Id, Country_Code, Country_Name, Continent) VALUES (8, 'UK', 'United Kingdom', 'Europe');
INSERT INTO Countries (Country_Id, Country_Code, Country_Name, Continent) VALUES (9, 'US', 'United States of America', 'North America');

INSERT INTO Languages (Language_Id, Language_Name) VALUES (1, 'Dutch');
INSERT INTO Languages (Language_Id, Language_Name) VALUES (2, 'English');
INSERT INTO Languages (Language_Id, Language_Name) VALUES (3, 'French');
INSERT INTO Languages (Language_Id, Language_Name) VALUES (4, 'German');
INSERT INTO Languages (Language_Id, Language_Name) VALUES (5, 'Maltese');
INSERT INTO Languages (Language_Id, Language_Name) VALUES (6, 'Spanish');

INSERT INTO Countries_Languages (CL_Id, Country_Id, Language_Id, Language_Category, Make_Flag) VALUES (1, 1, 6, 'MAIN', 0);
INSERT INTO Countries_Languages (CL_Id, Country_Id, Language_Id, Language_Category, Make_Flag) VALUES (2, 2, 4, 'MAIN', 1);
INSERT INTO Countries_Languages (CL_Id, Country_Id, Language_Id, Language_Category, Make_Flag) VALUES (3, 3, 3, 'MAIN', 1);
INSERT INTO Countries_Languages (CL_Id, Country_Id, Language_Id, Language_Category, Make_Flag) VALUES (4, 4, 2, 'MAIN', 1);
INSERT INTO Countries_Languages (CL_Id, Country_Id, Language_Id, Language_Category, Make_Flag) VALUES (5, 4, 5, 'MAIN', 0);
INSERT INTO Countries_Languages (CL_Id, Country_Id, Language_Id, Language_Category, Make_Flag) VALUES (6, 5, 6, 'MAIN', NULL);
INSERT INTO Countries_Languages (CL_Id, Country_Id, Language_Id, Language_Category, Make_Flag) VALUES (7, 6, 3, 'MAIN', 1);
INSERT INTO Countries_Languages (CL_Id, Country_Id, Language_Id, Language_Category, Make_Flag) VALUES (8, 6, 4, 'MAIN', 0);
INSERT INTO Countries_Languages (CL_Id, Country_Id, Language_Id, Language_Category, Make_Flag) VALUES (9, 6, 2, 'SECONDARY', 1);
INSERT INTO Countries_Languages (CL_Id, Country_Id, Language_Id, Language_Category, Make_Flag) VALUES (10, 7, 1, 'MAIN', 1);
INSERT INTO Countries_Languages (CL_Id, Country_Id, Language_Id, Language_Category, Make_Flag) VALUES (11, 7, 2, 'SECONDARY', 0);
INSERT INTO Countries_Languages (CL_Id, Country_Id, Language_Id, Language_Category, Make_Flag) VALUES (12, 8, 2, 'MAIN', 1);
INSERT INTO Countries_Languages (CL_Id, Country_Id, Language_Id, Language_Category, Make_Flag) VALUES (13, 9, 2, 'MAIN', 0);
