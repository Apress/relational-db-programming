-- Listing 6-3 Scalar functions Atomic Style Oracle
CREATE OR REPLACE FUNCTION get_category
(
	p_language_id INT,
	p_country_id INT
)
RETURN	VARCHAR2
AS
	v_category VARCHAR2(10);
	v_count INT;
BEGIN
	SELECT COUNT(*) INTO v_count FROM countries_languages
	WHERE language_id = p_language_id AND country_id = p_country_id;
	
	IF v_count = 0 THEN
		v_category := NULL;
	ELSE		
		SELECT Language_Category INTO v_category FROM countries_languages
		WHERE language_id = p_language_id AND country_id = p_country_id;
	END IF;	
	
	RETURN v_category;
END;
/
CREATE FUNCTION get_flag
(
	p_language_id INT,
	p_country_id INT
)
RETURN	INT
AS
	v_make_flag INT;
	v_count INT;
BEGIN
	SELECT COUNT(*) INTO v_count FROM countries_languages
	WHERE language_id = p_language_id AND country_id = p_country_id;
	
	IF v_count = 0 THEN
		v_make_flag := NULL;
	ELSE		
		SELECT Make_Flag INTO v_make_flag FROM countries_languages
		WHERE language_id = p_language_id AND country_id = p_country_id;
	END IF;	
	
	RETURN v_make_flag;
END;
/