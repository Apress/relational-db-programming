--- Listing 7-12 Atomic Get default quantity Oracle
CREATE OR REPLACE PROCEDURE Atomic_Get_Qtty_Per_Type
AS
  v_Product_Type_Code VARCHAR(5); 
  v_Make_Flag INT;
  v_Default_Quantity INT;
  v_First_Letter_Type CHAR(1);
  v_Current_Qtty INT;
  v_Current_Qtty_C INT;
  v_Current_Qtty_D INT;
  CURSOR c_Get_Products_Qtty IS
  SELECT pt.Product_Type_Code, p.Make_Flag, p.Default_Quantity
  FROM Product_Types pt INNER JOIN Products p 
	ON (p.Product_Type_Id = pt.Product_Type_Id);
BEGIN  
	v_Current_Qtty_C := 0;
	v_Current_Qtty_D := 0;
	v_Current_Qtty := 0;
	OPEN c_Get_Products_Qtty; 
  
	LOOP
		FETCH c_Get_Products_Qtty 
		INTO v_Product_Type_Code, v_Make_Flag, v_Default_Quantity;
  
		EXIT WHEN c_Get_Products_Qtty%NOTFOUND;	
		
		v_First_Letter_Type := SUBSTR(v_Product_Type_Code, 1, 1);
		
		IF v_First_Letter_Type = 'C' THEN
			IF v_Make_Flag = 1 THEN
				v_Current_Qtty := v_Default_Quantity * v_Default_Quantity;
			ELSIF v_Make_Flag = 0 THEN		
				v_Current_Qtty := 2 * v_Default_Quantity;
			END IF;
		ELSE
			IF v_Make_Flag = 1 THEN
				v_Current_Qtty := v_Default_Quantity * v_Default_Quantity - v_Default_Quantity;
			ELSIF v_Make_Flag = 0 THEN		
				v_Current_Qtty := 3 * v_Default_Quantity;
			END IF;
		END IF;	
		
		IF v_First_Letter_Type = 'C' THEN
			v_Current_Qtty_C := v_Current_Qtty_C + v_Current_Qtty;
		ELSE 
			v_Current_Qtty_D := v_Current_Qtty_D + v_Current_Qtty;
		END IF;	
	END LOOP;
	
	CLOSE c_Get_Products_Qtty;
	
	DBMS_OUTPUT.PUT_LINE ('The total default quantity for the products with C type is ' || TO_CHAR(v_Current_Qtty_C));
	
	DBMS_OUTPUT.PUT_LINE ('The total default quantity for the products with D type is ' || TO_CHAR(v_Current_Qtty_D));
END;
/