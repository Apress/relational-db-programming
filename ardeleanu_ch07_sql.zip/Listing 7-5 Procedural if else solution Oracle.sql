-- Listing 7-5 Procedural if else solution Oracle
CREATE OR REPLACE PROCEDURE Holistic_Full_Tr_Country_Proc
(
  p_Language_Name VARCHAR
)
AS
	v_English_Language_Id INT;
	v_French_Language_Id INT;
	v_Max_CL_Id INT;
BEGIN
	SELECT Language_Id INTO v_English_Language_Id
	FROM Languages WHERE Language_Name = 'English';

	SELECT Language_Id INTO v_French_Language_Id
	FROM Languages WHERE Language_Name = 'French';
	
	IF p_Language_Name = 'English' THEN
		DELETE Countries_Languages 
		WHERE Language_Id = v_English_Language_Id;	
	ELSIF p_Language_Name = 'French' THEN
		DELETE Countries_Languages 
		WHERE Language_Id = v_French_Language_Id;		
	ELSIF p_Language_Name = 'Both' THEN
		DELETE Countries_Languages 
		WHERE Language_Id = v_English_Language_Id;
		
		DELETE Countries_Languages 
		WHERE Language_Id = v_French_Language_Id;		
	END IF;		
	
	SELECT Max(CL_Id) INTO v_Max_CL_Id
	FROM Countries_Languages;
	
	IF v_Max_CL_Id IS NULL THEN
		v_Max_CL_Id := 0;
	END IF;	
	
	IF p_Language_Name = 'English' THEN
		INSERT INTO Countries_Languages  (CL_Id, Country_Id, Language_Id, Language_Category)
		SELECT v_Max_CL_Id + CL_Id_Seq.NextVal, c.Country_Id, v_English_Language_Id, eec.Language_Category
		FROM English_European_Countries eec INNER JOIN Countries c ON (c.Country_Code = eec.Country_Code);
	ELSIF p_Language_Name = 'French' THEN
		INSERT INTO Countries_Languages  (CL_Id, Country_Id, Language_Id, Language_Category)
		SELECT  v_Max_CL_Id + CL_ID_Seq.NextVal, c.Country_Id, v_French_Language_Id, eec.Language_Category
		FROM French_European_Countries eec INNER JOIN Countries c ON (c.Country_Code = eec.Country_Code);		
	ELSIF p_Language_Name = 'Both' THEN
		INSERT INTO Countries_Languages  (CL_Id, Country_Id, Language_Id, Language_Category)
		SELECT  v_Max_CL_Id + CL_ID_Seq.NextVal, c.Country_Id, v_English_Language_Id, eec.Language_Category
		FROM English_European_Countries eec INNER JOIN Countries c ON (c.Country_Code = eec.Country_Code);	

		INSERT INTO Countries_Languages  (CL_Id, Country_Id, Language_Id, Language_Category)
		SELECT  v_Max_CL_Id + CL_ID_Seq.NextVal, c.Country_Id, v_French_Language_Id, eec.Language_Category
		FROM French_European_Countries eec INNER JOIN Countries c ON (c.Country_Code = eec.Country_Code);			
	END IF;
	
	COMMIT;
END Holistic_Full_Tr_Country_Proc;
/