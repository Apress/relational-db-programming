-- Listing 7-1 Scalar function Atomic Style Oracle
CREATE FUNCTION Get_Type
(
	p_Product_Id INT
)
RETURN VARCHAR2
AS
	v_Type VARCHAR2 (255);
	v_Make_Flag INT;
BEGIN	
	SELECT Make_Flag INTO v_Make_Flag FROM Products WHERE Product_Id = p_Product_Id;
	
	IF (v_Make_Flag = 1) THEN
		SELECT t.Product_Type_Code INTO v_Type   
		FROM Product_Types t INNER JOIN Products p ON (p.Product_Type_Id = t.Product_Type_Id)
		WHERE p.Product_Id = p_Product_Id;	
	ELSE	
		SELECT t.Name INTO v_Type
		FROM Product_Types t INNER JOIN Products p ON (p.Product_Type_Id = t.Product_Type_Id)
		WHERE p.Product_Id = p_Product_Id;
	END IF;
	
	RETURN (v_Type);		
END;
/