-- Listing 6-10 Display Products Holistic SQL Server
CREATE PROCEDURE Get_Products_Holistically
AS
SELECT Product_Id, Current_Name, Previous_Name, Product_Code
FROM
(
	SELECT a.Product_Id, p_Current.Name AS Current_Name, p_Previous.Name AS Previous_Name, 
	CASE WHEN p_Current.Make_Flag = 1 THEN p_Previous.Product_Code ELSE p_Current.Product_Code END 
	AS Product_Code, 1 AS Type
	FROM
	(
		SELECT Product_Id, ROW_NUMBER () OVER (ORDER BY Product_Id) Current_Row_No, 
		ROW_NUMBER () OVER (ORDER BY Product_Id) -1 AS Previous_Row_No
		FROM Products
	) a INNER JOIN Products p_Current ON (p_Current.Product_Id = a.Product_Id)
	INNER JOIN 
	(
		SELECT Name, Product_Id, Product_Code, ROW_NUMBER () OVER (ORDER BY Product_Id) Row_No FROM Products 
	) p_Previous ON (p_Previous.Row_No = a.Previous_Row_No)
	UNION
	SELECT TOP 1 Product_Id, Name AS Current_Name, NULL AS Previous_Name, 
	CASE WHEN Make_Flag = 1 THEN NULL ELSE Product_Code END AS Product_Code, 0 AS Type
	FROM Products
	ORDER BY Type, Product_Id
) A
GO