-- Listing 7-14 Holistic Get default quantity SQL Server
CREATE PROCEDURE Atomic_Get_Qtty_Per_Type
AS
  DECLARE @v_Product_Type_Code VARCHAR(5), 
  @v_Make_Flag INT, @v_Default_Quantity INT,
  @v_First_Letter_Type CHAR(1),
  @v_Current_Qtty INT, @v_Current_Qtty_C INT, @v_Current_Qtty_D INT;
  DECLARE c_Get_Products_Qtty CURSOR FOR
  SELECT pt.Product_Type_Code, p.Make_Flag, p.Default_Quantity
  FROM Product_Types pt INNER JOIN Products p 
	ON (p.Product_Type_Id = pt.Product_Type_Id);
BEGIN  
	SET @v_Current_Qtty_C = 0;
	SET @v_Current_Qtty_D = 0;
	SET @v_Current_Qtty = 0;
	
	OPEN c_Get_Products_Qtty; 
  
	FETCH NEXT FROM  c_Get_Products_Qtty 
	INTO @v_Product_Type_Code, @v_Make_Flag, @v_Default_Quantity;
		
	WHILE @@FETCH_STATUS = 0
	BEGIN
  		SET @v_First_Letter_Type = SUBSTRING(@v_Product_Type_Code, 1, 1);
		
		IF @v_First_Letter_Type = 'C' 
		BEGIN
			IF @v_Make_Flag = 1 
				SET @v_Current_Qtty = @v_Default_Quantity * @v_Default_Quantity;
			ELSE IF @v_Make_Flag = 0 		
				SET @v_Current_Qtty = 2 * @v_Default_Quantity;
		END		
		ELSE
		BEGIN
			IF @v_Make_Flag = 1 
				SET @v_Current_Qtty = @v_Default_Quantity * @v_Default_Quantity - @v_Default_Quantity;
			ELSE IF @v_Make_Flag = 0 		
				SET @v_Current_Qtty = 3 * @v_Default_Quantity;
		END
		
		IF @v_First_Letter_Type = 'C' 
			SET @v_Current_Qtty_C = @v_Current_Qtty_C + @v_Current_Qtty;
		ELSE 
			SET @v_Current_Qtty_D = @v_Current_Qtty_D + @v_Current_Qtty;	
			
		FETCH NEXT FROM  c_Get_Products_Qtty 
		INTO @v_Product_Type_Code, @v_Make_Flag, @v_Default_Quantity;			
	END
	
	CLOSE c_Get_Products_Qtty;
	
	DEALLOCATE c_Get_Products_Qtty;
	
	PRINT('The total default quantity for the products with C type is ' + CAST(@v_Current_Qtty_C AS VARCHAR(20)));
	
	PRINT ('The total default quantity for the products with D type is ' + CAST(@v_Current_Qtty_D AS VARCHAR(20)));	
END;
GO