-- Listing 6-2 Full Filtered Data Transfer Atomic SQL Server
CREATE PROCEDURE Atomic_Transfer_Country_Flag
(
@p_Language_Name VARCHAR (50)
)
AS
	DECLARE @v_Country_Name VARCHAR (50), @v_Country_Code VARCHAR (3);
	DECLARE @v_Language_Category VARCHAR (10), @v_New_EEC_Id INT;
	DECLARE @v_Country_Id INT, @v_Language_Id INT, @v_Make_Flag INT;
	DECLARE c_Get_Countries_Lang CURSOR FOR
	SELECT Country_Id, Language_Id
	FROM Countries_Languages  
	WHERE Language_Id IN (SELECT Language_Id FROM Languages WHERE Language_Name = @p_Language_Name);
BEGIN  
	SET @v_New_EEC_Id = 1;
	IF @p_Language_Name = 'English' 
		DELETE English_European_Countries;
	ELSE IF @p_Language_Name = 'French' 
		DELETE French_European_Countries;	 
	OPEN c_Get_Countries_Lang 

	FETCH NEXT FROM c_Get_Countries_Lang 
	INTO @v_Country_Id, @v_Language_Id;

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		SET @v_Language_Category = dbo.get_category(@v_Language_Id, @v_Country_Id);
		
		IF @v_Language_Category = 'MAIN'
		BEGIN
			SET @v_Make_Flag = dbo.get_flag (@v_Language_Id, @v_Country_Id);
			
			IF @v_Make_Flag = 1			
			BEGIN	
				SELECT @v_Country_Name = Country_Name, @v_Country_Code = Country_Code FROM countries 
				WHERE Country_Id = @v_Country_Id;
				
				IF @p_Language_Name = 'English' 
					INSERT INTO English_European_Countries (English_CL_Id, Country_Code, Country_Name, Language_Category)
					VALUES (@v_New_EEC_Id, @v_Country_Code, @v_Country_Name, @v_Language_Category);		
				ELSE IF @p_Language_Name = 'French' 
					INSERT INTO French_European_Countries (French_CL_Id, Country_Code, Country_Name, Language_Category)
					VALUES (@v_New_EEC_Id, @v_Country_Code, @v_Country_Name, @v_Language_Category);	

				SET @v_New_EEC_Id = @v_New_EEC_Id + 1;		
			END	
		END	
		FETCH NEXT FROM c_Get_Countries_Lang INTO @v_Country_Id, @v_Language_Id;
	END
  
	CLOSE c_Get_Countries_Lang;

	DEALLOCATE c_Get_Countries_Lang;
END;
GO