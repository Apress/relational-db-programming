-- Listing 7-4 Update description holistic SQL Server
CREATE PROCEDURE Upd_Products_Desc_Holistic
AS
BEGIN
	UPDATE Products
	SET Product_Description = 
		CASE WHEN dest.Make_Flag = 1 AND SUBSTRING (t.Product_Type_Code, 1, 1) = 'C' 
					THEN 'DESC_' + dest.Product_Code + '_' + t.Product_Type_Code
				WHEN dest.Make_Flag = 0 AND SUBSTRING (t.Product_Type_Code, 1, 1) = 'C' 
					THEN 'DESC_' + dest.Product_Code + '_' + t.Name
				WHEN dest.Make_Flag = 0 AND SUBSTRING (t.Product_Type_Code, 1, 1) <> 'C' 
					THEN 'DESC_' + t.Name
				WHEN dest.Make_Flag = 1 AND SUBSTRING (t.Product_Type_Code, 1, 1) <> 'C'   
					THEN 'DESC_' + t.Product_Type_Code
		END		    
	FROM Products dest INNER JOIN Product_Types t ON (t.Product_Type_Id = dest.Product_Type_Id);
END
GO	