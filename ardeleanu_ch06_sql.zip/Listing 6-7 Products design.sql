-- Listing 6-7 Products design
CREATE TABLE Product_Types
(
 Product_Type_Id INT CONSTRAINT Nn_Product_Type_Id NOT NULL,
 Product_Type_Code VARCHAR (5) CONSTRAINT Nn_Product_Type_Code NOT NULL,
 Name VARCHAR (255) CONSTRAINT Nn_Product_Type_Name NOT NULL,
 CONSTRAINT Pk_Product_Type_Id PRIMARY KEY (Product_Type_Id)
);
CREATE TABLE Products
(
 Product_Id INT CONSTRAINT Nn_Product_Id NOT NULL,
 Name VARCHAR (30) CONSTRAINT Nn_Product_Name NOT NULL,
 Product_Code VARCHAR (5) CONSTRAINT Nn_Product_Code NOT NULL,
 Product_Description VARCHAR (255),
 Make_Flag INT,
 Product_Type_Id INT,
 Default_Quantity INT,
 CONSTRAINT Pk_Product_Id PRIMARY KEY (Product_Id),
 CONSTRAINT Fk_Products_Product_Types FOREIGN KEY (Product_Type_Id) 
 REFERENCES Product_Types (Product_Type_Id)
);