-- Listing 7-2 Update description atomic Oracle
CREATE PROCEDURE Upd_Products_Desc_Atomic
AS
	v_Product_Id INT;
	v_Product_Type_Code VARCHAR2 (5);	
	v_Product_Code VARCHAR2 (5);
	v_Description VARCHAR2 (255);
	v_Generated_Type VARCHAR2 (255);
	v_rid ROWID;
	
	CURSOR c_Get_Products IS
	SELECT Product_Id, rowid  FROM Products FOR UPDATE OF Product_Description; 
BEGIN	
	OPEN c_Get_Products;
	
	LOOP
		EXIT WHEN c_Get_Products%NOTFOUND;
		
		FETCH c_Get_Products INTO v_Product_Id, v_rid;
	
		v_Generated_Type := Get_Type(v_Product_Id);
		
		SELECT p.Product_Code, t.Product_Type_Code INTO v_Product_Code, v_Product_Type_Code 
		FROM Products p INNER JOIN Product_Types t ON (p.Product_Type_Id = t.Product_Type_Id)
		WHERE p.Product_Id = v_Product_Id;
		
		v_Description := 'DESC_';
		
		IF (SUBSTR (v_Product_Type_Code, 1, 1) = 'C') THEN
			v_Description := v_Description || v_Product_Code;
		END IF;	
		
		IF SUBSTR (v_Description, LENGTH (v_Description), 1) <> '_' THEN
			v_Description := v_Description || '_';
		END IF;
			
		v_Description := v_Description || v_Generated_Type;

		UPDATE Products	
		SET Product_Description = v_Description
		WHERE rowid = v_rid;

	END LOOP;

	COMMIT;

	CLOSE c_Get_Products;
END;
/	