-- Listing 8-4 Holistic full transfer with triggers Oracle
CREATE OR REPLACE PROCEDURE Holistic_Full_Transf_Country
(
  p_Language_Name VARCHAR
)
AS
BEGIN
	DELETE English_European_Countries 
	WHERE p_Language_Name = 'English';
	
	DELETE French_European_Countries 
	WHERE p_Language_Name = 'French';
	
    INSERT INTO English_European_Countries (Country_Code, Country_Name, Language_Category)
	SELECT c.Country_Code, c.Country_Name, cl.Language_Category
	FROM Countries_Languages cl INNER JOIN Languages l 
		ON (l.Language_Id = cl.Language_Id)
	INNER JOIN Countries c 
		ON (c.Country_Id = cl.Country_Id) 
	WHERE l.Language_Name = p_Language_Name AND p_Language_Name = 'English';
	
    INSERT INTO French_European_Countries (Country_Code, Country_Name, Language_Category)
	SELECT c.Country_Code, c.Country_Name, cl.Language_Category
	FROM Countries_Languages cl INNER JOIN Languages l 
		ON (l.Language_Id = cl.Language_Id)
	INNER JOIN Countries c 
		ON (c.Country_Id = cl.Country_Id) 
	WHERE l.Language_Name = p_Language_Name AND p_Language_Name = 'French';	
	
	COMMIT;
END Holistic_Full_Transf_Country;
/