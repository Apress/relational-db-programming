--- Listing 9-1 Writing vertically
INSERT INTO Countries_Languages (
	CL_Id, 
	Country_Id, 
	Language_Id, 
	Language_Category
	)VALUES (
	14, 
	2, 
	2, 
	'SECONDARY');
	
-- Writing horizontally 	
INSERT INTO Countries_Languages (CL_Id, Country_Id, Language_Id, Language_Category)
VALUES (14, 2, 2, 'SECONDARY');	