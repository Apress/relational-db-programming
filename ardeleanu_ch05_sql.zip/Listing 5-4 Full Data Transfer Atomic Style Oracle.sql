-- Listing 5-4 Full Data Transfer Atomic Style Oracle 
CREATE PROCEDURE Atomic_Full_Transfer_Country
(p_Language_Name VARCHAR)
AS
  v_Country_Name VARCHAR2(50); 
  v_Country_Code VARCHAR2(3);
  v_Language_Category VARCHAR2(10); 
  v_New_EEC_Id INT;
  
  CURSOR c_Get_Countries (p_Language VARCHAR2) IS
  SELECT c.Country_Name, c.Country_Code, cl.Language_Category
  FROM Countries_Languages cl INNER JOIN Languages l 
	ON (l.Language_Id = cl.Language_Id)
  INNER JOIN Countries c
	ON (c.Country_Id = cl.Country_Id) 
  WHERE l.Language_Name = p_Language;
BEGIN
  v_New_EEC_Id := 1;
  IF p_Language_Name = 'English' THEN
	DELETE English_European_Countries;
  ELSIF p_Language_Name = 'French' THEN
	DELETE French_European_Countries;
  END IF;	
  
  OPEN c_Get_Countries (p_Language_Name);
  LOOP
  FETCH c_Get_Countries 
	INTO v_Country_Name, v_Country_Code, v_Language_Category;
  
  EXIT WHEN c_Get_Countries%NOTFOUND;
  
	IF p_Language_Name = 'English' THEN 
		INSERT INTO English_European_Countries (English_CL_Id, Country_Code, Country_Name, Language_Category)
		VALUES (v_New_EEC_Id, v_Country_Code, v_Country_Name, v_Language_Category);
	ELSIF p_Language_Name = 'French' THEN
		INSERT INTO French_European_Countries (French_CL_Id, Country_Code, Country_Name, Language_Category)
		VALUES (v_New_EEC_Id, v_Country_Code, v_Country_Name, v_Language_Category);
	END IF;		
  
  v_New_EEC_Id := v_New_EEC_Id + 1;
  COMMIT;
  END LOOP;
  
  CLOSE c_Get_Countries;
END Atomic_Full_Transfer_Country;
/