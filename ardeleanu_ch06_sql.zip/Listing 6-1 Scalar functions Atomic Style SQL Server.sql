-- Listing 6-1 Scalar functions Atomic Style SQL Server
CREATE FUNCTION get_category
(
	@p_language_id INT,
	@p_country_id INT
)
RETURNS	VARCHAR(10)
BEGIN
	DECLARE @v_category VARCHAR(10);
	DECLARE @v_count INT;
	
	SELECT @v_count = COUNT(*) FROM countries_languages
	WHERE language_id = @p_language_id AND country_id = @p_country_id;
	
	IF @v_count = 0
		SET @v_category = NULL
	ELSE		
		SELECT @v_category = Language_Category FROM countries_languages
		WHERE language_id = @p_language_id AND country_id = @p_country_id;
	
	RETURN @v_category;
END
GO
CREATE FUNCTION get_flag
(
	@p_language_id INT,
	@p_country_id INT
)
RETURNS	INT
BEGIN
	DECLARE @v_make_flag INT
	DECLARE @v_count 	INT
	
	SELECT @v_count = COUNT(*) FROM countries_languages
	WHERE language_id = @p_language_id AND country_id = @p_country_id;
	
	IF @v_count = 0
		SET @v_make_flag = NULL
	ELSE		
		SELECT @v_make_flag = Make_Flag FROM countries_languages
		WHERE language_id = @p_language_id AND country_id = @p_country_id;
	
	RETURN @v_make_flag;
END
GO