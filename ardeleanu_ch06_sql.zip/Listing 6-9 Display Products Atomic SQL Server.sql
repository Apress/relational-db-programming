-- Listing 6-9 Display Products Atomic SQL Server
CREATE PROCEDURE Get_Products_Atomically
AS
BEGIN
  DECLARE @v_Product_Id NUMERIC (10, 0), @v_Prev_Product_Code NVARCHAR (5); 
  DECLARE @v_First_Name NVARCHAR (30), @v_First_Product_Code NVARCHAR (200)
  DECLARE @v_Current_Name NVARCHAR (30), @v_Min1_Product_Id NUMERIC (10, 0);
  DECLARE @v_Previous_Name  NVARCHAR (30), @v_Product_Code NVARCHAR (200);
  DECLARE @v_Min_Product_Id NUMERIC (10, 0), @v_Make_Flag INT;

  DECLARE @v_Products TABLE(Product_Id INT, Current_Name NVARCHAR (30), 
  Previous_Name NVARCHAR (30), Product_Code NVARCHAR (5));
 
  SELECT @v_Min_Product_Id =  MIN (Product_Id) FROM Products;
  SELECT @v_Min1_Product_Id = MIN (Product_Id) 
  FROM Products WHERE Product_Id > @v_Min_Product_Id;
  
  SELECT @v_First_Name = Name FROM Products WHERE Product_Id = @v_Min_Product_Id;
  SELECT @v_First_Product_Code = Product_Code FROM Products WHERE Product_Id = @v_Min_Product_Id;
  
  INSERT INTO @v_Products (Product_Id, Current_Name, Product_Code)
  SELECT Product_Id, Name, 
  CASE WHEN Make_Flag = 1 THEN NULL ELSE Product_Code END AS Product_Code
  FROM Products WHERE Product_Id = @v_Min_Product_Id;
	
  DECLARE c_Products CURSOR FOR
  SELECT Product_Id, Name, Product_Code, Make_Flag FROM Products
  WHERE Product_Id > @v_Min_Product_Id 
  ORDER BY 1; 
 
  OPEN c_Products;
  
  FETCH NEXT FROM c_Products 
  INTO @v_Product_Id, @v_Current_Name, @v_Product_Code, @v_Make_Flag;
  
  WHILE (@@FETCH_STATUS = 0)
  BEGIN
	IF (@v_Min1_Product_Id = @v_Product_Id)
	BEGIN
		SET @v_Previous_Name = @v_First_Name; 
			
		IF (@v_Make_Flag = 1)
			SET @v_Prev_Product_Code = @v_First_Product_Code;
		ELSE
			SET @v_Prev_Product_Code = @v_Product_Code;
   
		INSERT INTO @v_Products (Product_Id, Current_Name, Previous_Name, Product_Code)
		SELECT @v_Product_Id, @v_Current_Name, @v_Previous_Name, @v_Prev_Product_Code
			
		SET @v_Previous_Name = @v_Current_Name; 
	END
	ELSE
	BEGIN  
		IF (@v_Make_Flag = 0)
			SET @v_Prev_Product_Code = @v_Product_Code;  

	   INSERT INTO @v_Products (Product_Id, Current_Name, Previous_Name, Product_Code)
	   SELECT @v_Product_Id, @v_Current_Name, @v_Previous_Name, @v_Prev_Product_Code  
  
	   SET @v_Previous_Name = @v_Current_Name; 
	   SET @v_Prev_Product_Code = @v_Product_Code;  
	END  
   
	FETCH NEXT FROM c_Products 
	INTO @v_Product_Id, @v_Current_Name, @v_Product_Code, @v_Make_Flag;
  END;
  
  CLOSE c_Products;
  
  DEALLOCATE c_Products;
  
  SELECT * FROM @v_Products
END
GO
