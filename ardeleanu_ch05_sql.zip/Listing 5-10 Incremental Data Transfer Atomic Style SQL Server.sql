-- Listing 5-10 Incremental Data Transfer Atomic Style SQL Server
CREATE PROCEDURE Atomic_Inc_Transfer_English
AS
	DECLARE @v_Country_Name VARCHAR (50);
	DECLARE @v_Country_Code VARCHAR (3);
	DECLARE @v_Language_Category VARCHAR (10);
	DECLARE @v_Next_EEC_Id INT;
	DECLARE @v_Count INT;	
	
	DECLARE c_Existing_Countries CURSOR FOR
	SELECT Country_Code, Language_Category
	FROM English_European_Countries;	

	DECLARE c_Get_New_Countries CURSOR FOR
	SELECT c.Country_Name, c.Country_Code, cl.Language_Category
	FROM Countries_Languages cl INNER JOIN Languages l 
		ON (l.Language_Id = cl.Language_Id)
	INNER JOIN Countries c ON (c.Country_Id = cl.Country_Id)
	WHERE l.Language_Name = 'English'; 
BEGIN         
	OPEN c_Existing_Countries;

	FETCH NEXT FROM c_Existing_Countries INTO @v_Country_Code, @v_Language_Category;
 
WHILE (@@FETCH_STATUS = 0)
BEGIN
SET @v_Count = (SELECT COUNT (1) 
FROM Countries_Languages cl INNER JOIN Languages l 
	ON (l.Language_Id = cl.Language_Id)
INNER JOIN Countries c ON (c.Country_Id = cl.Country_Id)
WHERE l.Language_Name = 'English'
AND c.Country_Code = @v_Country_Code AND cl.Language_Category = @v_Language_Category
			);
IF (@v_Count = 0)
BEGIN
	DELETE English_European_Countries
	WHERE Country_Code = @v_Country_Code AND Language_Category = @v_Language_Category;
END;			

FETCH NEXT FROM c_Existing_Countries INTO @v_Country_Code, @v_Language_Category;
END
 
 CLOSE c_Existing_Countries;
 
 DEALLOCATE c_Existing_Countries;
 
 OPEN c_Get_New_Countries 
 
 FETCH NEXT FROM c_Get_New_Countries INTO @v_Country_Name, @v_Country_Code, @v_Language_Category;
 
 WHILE (@@FETCH_STATUS = 0)
 BEGIN

		SELECT @v_Count = COUNT(*) 
		WHERE NOT EXISTS 
		(
			SELECT 1 
			FROM English_European_Countries eec1
			WHERE eec1.Country_Code = @v_Country_Code 
			AND eec1.Language_Category = @v_Language_Category
		);
	
	IF (@v_Count = 1)
	BEGIN
		SET @v_Next_EEC_Id = (SELECT MAX (English_CL_Id) + 1 FROM English_European_Countries);
		
		INSERT INTO English_European_Countries (English_CL_Id, Country_Code, Country_Name, Language_Category)
		VALUES (@v_Next_EEC_Id, @v_Country_Code, @v_Country_Name, @v_Language_Category);
	END;
 
 FETCH NEXT FROM c_Get_New_Countries INTO @v_Country_Name, @v_Country_Code, @v_Language_Category;
 END 
  
 CLOSE c_Get_New_Countries;
 
 DEALLOCATE c_Get_New_Countries;
END;
GO