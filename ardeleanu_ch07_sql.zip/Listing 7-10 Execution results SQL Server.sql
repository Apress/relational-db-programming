-- Listing 7-10 Execution results SQL Server
DELETE English_European_Countries;
INSERT INTO English_European_Countries (English_CL_Id, Country_Code, Country_Name, Language_Category) 
SELECT ROW_NUMBER() OVER (ORDER BY c.Country_Code, cl.Language_Category) AS CL_Id, c.Country_Code, 
 	c.Country_Name, cl.Language_Category
 	FROM Countries_Languages cl INNER JOIN Languages l ON (l.Language_Id = cl.Language_Id)
 	INNER JOIN Countries c ON (c.Country_Id = cl.Country_Id) 
 	WHERE l.Language_Name = 'English';
DELETE French_European_Countries;
INSERT INTO French_European_Countries (French_CL_Id, Country_Code, Country_Name, Language_Category) 
SELECT ROW_NUMBER() OVER (ORDER BY c.Country_Code, cl.Language_Category) AS CL_Id, c.Country_Code, 
 	c.Country_Name, cl.Language_Category
 	FROM Countries_Languages cl INNER JOIN Languages l ON (l.Language_Id = cl.Language_Id)
 	INNER JOIN Countries c ON (c.Country_Id = cl.Country_Id) 
 	WHERE l.Language_Name = 'French';
