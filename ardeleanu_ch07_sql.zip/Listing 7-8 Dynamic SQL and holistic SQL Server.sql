-- Listing 7-8 Dynamic SQL and holistic SQL Server
CREATE PROCEDURE Holistic_Full_Country_Dynamic
AS
	DECLARE @v_Language_Id INT;
	DECLARE @v_Language_Name VARCHAR(50);
	DECLARE @v_Language_Table_Name VARCHAR(30);
	DECLARE @v_SQL_Statement NVARCHAR(1000);
	DECLARE c_Get_Languages CURSOR FOR
	SELECT Language_Id, Language_Name, Language_Table_Name
	FROM Languages 
	WHERE Language_Table_Name IS NOT NULL;
BEGIN
	OPEN c_Get_Languages
	
	FETCH NEXT FROM c_Get_Languages INTO  @v_Language_Id, @v_Language_Name, @v_Language_Table_Name
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
 SET @v_SQL_Statement = 'DELETE ' + @v_Language_Table_Name;
 
 EXECUTE sp_executesql @v_SQL_Statement
 
 SET @v_SQL_Statement = 'INSERT INTO ' + @v_Language_Table_Name + ' (' + @v_Language_Name + '_CL_Id, Country_Code, Country_Name, Language_Category)' + 
 ' SELECT ROW_NUMBER() OVER (ORDER BY c.Country_Code, cl.Language_Category) AS CL_Id, c.Country_Code, 
 	c.Country_Name, cl.Language_Category
 	FROM Countries_Languages cl INNER JOIN Languages l ON (l.Language_Id = cl.Language_Id)
 	INNER JOIN Countries c ON (c.Country_Id = cl.Country_Id) 
 	WHERE l.Language_Name = ''' + @v_Language_Name + '''';  
 
 	EXECUTE sp_executesql @v_SQL_Statement
 	
 FETCH NEXT FROM c_Get_Languages INTO  @v_Language_Id, @v_Language_Name, @v_Language_Table_Name
	END
	
	CLOSE c_Get_Languages
	
	DEALLOCATE c_Get_Languages
END	
GO