-- Listing 5-2 The destination system design
CREATE TABLE English_European_Countries
(
	English_CL_Id INT CONSTRAINT NN_English_CL_Id NOT NULL,
	Country_Code VARCHAR(3) CONSTRAINT NN_LCountry_Code NOT NULL,
	Country_Name VARCHAR(50) CONSTRAINT NN_LCountry_Name NOT NULL,
	Language_Category VARCHAR(10),
	CONSTRAINT PK_English_CL_Id PRIMARY KEY (English_CL_Id),
	CONSTRAINT UQ_ECountry_Code_Category UNIQUE (Country_Code, Language_Category)
);

CREATE TABLE French_European_Countries
(
	French_CL_Id INT CONSTRAINT NN_French_CL_Id NOT NULL,
	Country_Code VARCHAR(3) CONSTRAINT NN_FCountry_Code NOT NULL,
	Country_Name VARCHAR(50) CONSTRAINT NN_FCountry_Name NOT NULL,
	Language_Category VARCHAR(10),
	CONSTRAINT PK_French_CL_Id PRIMARY KEY (French_CL_Id),
	CONSTRAINT UQ_FCountry_Code_Category UNIQUE (Country_Code, Language_Category)
);

-- Others reporting tables may be added per various languages.