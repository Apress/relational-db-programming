-- Listing 6-4 Full Filtered Data Transfer Atomic Oracle
CREATE OR REPLACE PROCEDURE Atomic_Transfer_Country_Flag
(
 p_Language_Name VARCHAR 
)
AS
  v_Country_Name VARCHAR (50); 
  v_Country_Code VARCHAR (3);
  v_Language_Category VARCHAR (10); 
  v_New_EEC_Id INT;
  v_Country_Id INT; 
  v_Language_Id INT; 
  v_Make_Flag INT;
  CURSOR c_Get_Countries_Lang IS
 SELECT Country_Id, Language_Id
 FROM Countries_Languages 
 WHERE Language_Id IN (SELECT Language_Id FROM Languages WHERE Language_Name = p_Language_Name);
BEGIN 
	v_New_EEC_Id := 1;
	IF p_Language_Name = 'English' THEN
		DELETE English_European_Countries;
	ELSIF p_Language_Name = 'French' THEN
		DELETE French_European_Countries;	 
	END IF;	
	OPEN c_Get_Countries_Lang; 
 
	LOOP
		FETCH c_Get_Countries_Lang INTO v_Country_Id, v_Language_Id;
		
		EXIT WHEN c_Get_Countries_Lang%NOTFOUND;
			v_Language_Category := get_category(v_Language_Id, v_Country_Id);
			
			IF v_Language_Category = 'MAIN' THEN
				v_Make_Flag := get_flag (v_Language_Id, v_Country_Id);
				
				IF v_Make_Flag = 1 THEN			
					SELECT Country_Name, Country_Code INTO v_Country_Name, v_Country_Code 
					FROM countries WHERE Country_Id = v_Country_Id;
					
					IF p_Language_Name = 'English' THEN
						INSERT INTO English_European_Countries (English_CL_Id, Country_Code, Country_Name, Language_Category)
						VALUES (v_New_EEC_Id, v_Country_Code, v_Country_Name, v_Language_Category);		
					ELSIF p_Language_Name = 'French' THEN
						INSERT INTO French_European_Countries (French_CL_Id, Country_Code, Country_Name, Language_Category)
						VALUES (v_New_EEC_Id, v_Country_Code, v_Country_Name, v_Language_Category);	
					END IF;
					
					v_New_EEC_Id := v_New_EEC_Id + 1;		
				END IF;	
			END IF;	
		COMMIT;
	END LOOP;
 CLOSE c_Get_Countries_Lang;
END;
/