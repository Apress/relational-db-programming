-- Listing 5-11 Incremental Data Transfer Holistic Style SQL Server
CREATE PROCEDURE Holistic_Inc_Transfer_English
AS
BEGIN
	DELETE FROM English_European_Countries
	FROM English_European_Countries eec
	WHERE NOT EXISTS 
	(
		SELECT 1 
		FROM Countries_Languages cl INNER JOIN Languages l ON (l.Language_Id = cl.Language_Id)
		INNER JOIN Countries c ON (c.Country_Id = cl.Country_Id)
		WHERE l.Language_Name = 'English'
		AND eec.Country_Code = c.Country_Code 
		AND eec.Language_Category = cl.Language_Category
	);
	
	INSERT INTO English_European_Countries (English_CL_Id, Country_Code, Country_Name, Language_Category)
	SELECT (SELECT MAX (English_CL_Id) AS Max_English_CL_Id FROM English_European_Countries) + ROW_NUMBER() OVER (ORDER BY c.Country_Code, cl.Language_Category) AS English_CL_Id, c.Country_Code, 
	c.Country_Name, cl.Language_Category
	FROM Countries_Languages cl INNER JOIN Languages l ON (l.Language_Id = cl.Language_Id)
	INNER JOIN Countries c ON (c.Country_Id = cl.Country_Id) 
	WHERE l.Language_Name = 'English'
	AND NOT EXISTS 
	(
		SELECT 1 FROM English_European_Countries eec
		WHERE eec.Language_Category = cl.Language_Category AND eec.Country_Code = c.Country_Code
	); 
END;
GO