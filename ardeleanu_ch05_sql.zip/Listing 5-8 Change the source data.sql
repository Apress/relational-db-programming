-- Listing 5-8 Change the source data
UPDATE Countries_Languages
SET Language_Category = 'SECONDARY'
WHERE Country_Id = 4 AND Language_Id = 2;

DELETE Countries_Languages
WHERE Country_Id = 6 AND Language_Id = 2;

INSERT INTO Countries_Languages (CL_Id, Country_Id, Language_Id, Language_Category)
VALUES (14, 2, 2, 'SECONDARY');

INSERT INTO Languages (Language_Id, Language_Name) 
VALUES (7, 'Algerian Arabic');

INSERT INTO Countries (Country_Id, Country_Code, Country_Name, Continent) 
VALUES (10, 'Ag', 'Algeria', 'Africa');

INSERT INTO Countries_Languages (CL_Id, Country_Id, Language_Id, Language_Category)
VALUES (15, 10, 7, 'MAIN');

INSERT INTO Countries_Languages (CL_Id, Country_Id, Language_Id, Language_Category)
VALUES (16, 10, 3, 'SECONDARY');
