-- Listing 7-15 Another Holistic method SQL Server
CREATE PROCEDURE Holistic_Get_Qtty_Per_Type
AS
BEGIN
	CREATE TABLE #types_and_quantities (Type_Code_Prefix CHAR(1), Current_Qtty INT);
  
	INSERT INTO #types_and_quantities (Type_Code_Prefix, Current_Qtty)
	SELECT SUBSTRING(pt.Product_Type_Code, 1, 1) AS Type_Code_Prefix, 
	CASE WHEN p.Make_Flag = 1 THEN p.Default_Quantity * p.Default_Quantity 
	WHEN  p.Make_Flag = 0 THEN 2 * p.Default_Quantity
	ELSE NULL END AS Current_Qtty
	FROM Product_Types pt INNER JOIN Products p 
	ON (p.Product_Type_Id = pt.Product_Type_Id)
	WHERE SUBSTRING(pt.Product_Type_Code, 1, 1) = 'C';
	
	INSERT INTO #types_and_quantities (Type_Code_Prefix, Current_Qtty)	
	SELECT SUBSTRING(pt.Product_Type_Code, 1, 1) AS Type_Code, 
	CASE WHEN p.Make_Flag = 1 THEN p.Default_Quantity * p.Default_Quantity - p.Default_Quantity
	WHEN  p.Make_Flag = 0 THEN 3 * p.Default_Quantity
	ELSE NULL END AS Current_Qtty
	FROM Product_Types pt INNER JOIN Products p 
	ON (p.Product_Type_Id = pt.Product_Type_Id)
	WHERE SUBSTRING(pt.Product_Type_Code, 1, 1) = 'D';	
	
	SELECT Type_Code_Prefix, SUM(Current_Qtty) AS Current_Qtty
	FROM #types_and_quantities
	GROUP BY Type_Code_Prefix;
END;
GO