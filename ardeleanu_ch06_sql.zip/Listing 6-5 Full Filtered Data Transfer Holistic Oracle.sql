-- Code example 19: Oracle Holistic Inc transfer new filter conditions
CREATE OR REPLACE PROCEDURE Holistic_Transfer_Country_Flag
(
  p_Language_Name VARCHAR
)
AS
BEGIN
	DELETE English_European_Countries WHERE p_Language_Name = 'English';
	
	DELETE French_European_Countries WHERE p_Language_Name = 'French';
	
    INSERT INTO English_European_Countries (English_CL_Id, Country_Code, Country_Name, Language_Category)
	SELECT ROW_NUMBER() OVER (ORDER BY c.Country_Code, cl.Language_Category) AS English_CL_Id, c.Country_Code, 
	c.Country_Name, cl.Language_Category
	FROM Countries_Languages cl INNER JOIN Languages l ON (l.Language_Id = cl.Language_Id)
	INNER JOIN Countries c ON (c.Country_Id = cl.Country_Id) 
	WHERE l.Language_Name = p_Language_Name AND p_Language_Name = 'English' AND cl.Language_Category = 'MAIN' AND cl.Make_Flag = 1;
	
    INSERT INTO French_European_Countries (French_CL_Id, Country_Code, Country_Name, Language_Category)
	SELECT ROW_NUMBER() OVER (ORDER BY c.Country_Code, cl.Language_Category) AS French_CL_Id, c.Country_Code, 
	c.Country_Name, cl.Language_Category
	FROM Countries_Languages cl INNER JOIN Languages l ON (l.Language_Id = cl.Language_Id)
	INNER JOIN Countries c ON (c.Country_Id = cl.Country_Id) 
	WHERE l.Language_Name = p_Language_Name AND p_Language_Name = 'French' AND cl.Language_Category = 'MAIN' AND cl.Make_Flag = 1;	
	
	COMMIT;
  
END Holistic_Transfer_Country_Flag;
/