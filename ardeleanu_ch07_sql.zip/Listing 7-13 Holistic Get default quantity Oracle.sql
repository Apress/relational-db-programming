-- Listing 7-13 Holistic Get default quantity Oracle
WITH types_quantities AS (
	SELECT SUBSTR(pt.Product_Type_Code, 1, 1) AS Type_Code, 
	CASE WHEN p.Make_Flag = 1 THEN p.Default_Quantity * p.Default_Quantity 
	WHEN  p.Make_Flag = 0 THEN 2 * p.Default_Quantity
	ELSE NULL END AS Current_Qtty
	FROM Product_Types pt INNER JOIN Products p 
	ON (p.Product_Type_Id = pt.Product_Type_Id)
	WHERE SUBSTR(pt.Product_Type_Code, 1, 1) = 'C'
	UNION ALL
	SELECT SUBSTR(pt.Product_Type_Code, 1, 1) AS Type_Code, 
	CASE WHEN p.Make_Flag = 1 THEN p.Default_Quantity * p.Default_Quantity - p.Default_Quantity
	WHEN  p.Make_Flag = 0 THEN 3 * p.Default_Quantity
	ELSE NULL END AS Current_Qtty
	FROM Product_Types pt INNER JOIN Products p 
	ON (p.Product_Type_Id = pt.Product_Type_Id)
	WHERE SUBSTR(pt.Product_Type_Code, 1, 1) = 'D' 
						)
SELECT Type_Code, SUM(Current_Qtty) AS Current_Qtty
FROM types_quantities
GROUP BY Type_Code;