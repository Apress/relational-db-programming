-- Listing 1-1: Design of a table
CREATE TABLE Students
(
	Student_Id INT NOT NULL,
	Student_Name VARCHAR (30) NOT NULL,
	SSN VARCHAR (30) NOT NULL,
	Locality_Id INT,
	Birth_Date DATE,
	Gender VARCHAR (10) NOT NULL
);
ALTER TABLE Students
ADD CONSTRAINT PK_Students_Student_Id 
PRIMARY KEY (Student_Id);
ALTER TABLE Students
ADD CONSTRAINT UQ_Students_SSN 
UNIQUE (Student_Id);
ALTER TABLE Students
ADD CONSTRAINT CK_Students_Gender 
CHECK (Gender IN ('Male', 'Female'));
ALTER TABLE Students
ADD CONSTRAINT FK_Students_Localities 
FOREIGN KEY (Locality_Id)
REFERENCES Localities (Locality_Id);
