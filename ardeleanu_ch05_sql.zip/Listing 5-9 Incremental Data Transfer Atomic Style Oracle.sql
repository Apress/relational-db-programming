-- Listing 5-9 Incremental Data Transfer Atomic Style Oracle
CREATE PROCEDURE Atomic_Inc_Transfer_English
AS
	v_Country_Name VARCHAR (50);
	v_Country_Code VARCHAR (3);
	v_Language_Category VARCHAR (10);
	v_Next_EEC_Id  INT;
	v_Count INT;	
	
	CURSOR c_Existing_Countries IS
	SELECT Country_Code, Language_Category
	FROM English_European_Countries;
	
	CURSOR c_New_Countries IS
	SELECT c.Country_Name, c.Country_Code, cl.Language_Category
	FROM Countries_Languages cl INNER JOIN Languages l 
		ON (l.Language_Id = cl.Language_Id)
	INNER JOIN Countries c ON (c.Country_Id = cl.Country_Id)
	WHERE l.Language_Name = 'English';
BEGIN
	OPEN c_Existing_Countries;
	
	LOOP
		FETCH c_Existing_Countries INTO v_Country_Code, v_Language_Category;
		
		EXIT WHEN c_Existing_Countries%NOTFOUND;
  
		SELECT COUNT(1) INTO v_Count 
		FROM Countries_Languages cl INNER JOIN Languages l 
			ON (l.Language_Id = cl.Language_Id)
		INNER JOIN Countries c ON (c.Country_Id = cl.Country_Id)
		WHERE l.Language_Name = 'English'
		AND c.Country_Code = v_Country_Code AND cl.Language_Category = v_Language_Category;
		
		IF (v_Count = 0) THEN
			DELETE English_European_Countries
			WHERE Country_Code = v_Country_Code AND Language_Category = v_Language_Category;
		END IF;
		
		COMMIT;
	END LOOP;			
  
	CLOSE c_Existing_Countries;
  
	OPEN c_New_Countries; 
  
	LOOP
		FETCH c_New_Countries INTO v_Country_Name, v_Country_Code, v_Language_Category;
		
		EXIT WHEN c_New_Countries%NOTFOUND;
 
		SELECT COUNT(*) INTO v_Count FROM dual
		WHERE NOT EXISTS 
		(
			SELECT 1 
			FROM English_European_Countries eec1
			WHERE eec1.Country_Code = v_Country_Code 
			AND eec1.Language_Category = v_Language_Category
		);
	
		IF (v_Count = 1) THEN
			SELECT MAX (English_CL_Id) + 1 INTO v_Next_EEC_Id FROM English_European_Countries;
		
			INSERT INTO English_European_Countries (English_CL_Id, Country_Code, Country_Name, Language_Category)
			VALUES (v_Next_EEC_Id, v_Country_Code, v_Country_Name, v_Language_Category);
		END IF;
		
		COMMIT;
  
	END LOOP; 
  
  CLOSE c_New_Countries;
END Atomic_Inc_Transfer_English;
/