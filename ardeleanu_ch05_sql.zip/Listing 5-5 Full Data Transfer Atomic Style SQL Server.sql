-- Listing 5-5 Full Data Transfer Atomic Style SQL Server
CREATE PROCEDURE Atomic_Full_Transfer_Country
(
  @p_Language_Name VARCHAR(50)
)
AS
  DECLARE @v_Country_Name VARCHAR(50);
  DECLARE @v_Country_Code VARCHAR(3);
  DECLARE @v_Language_Category VARCHAR(10);
  DECLARE @v_New_EEC_Id INT;
  DECLARE c_Get_Countries CURSOR FOR
  SELECT c.Country_Name, c.Country_Code, cl.Language_Category
  FROM Countries_Languages cl INNER JOIN Languages l 
	ON (l.Language_Id = cl.Language_Id)
  INNER JOIN Countries c 
	ON (c.Country_Id = cl.Country_Id) 
  WHERE UPPER(l.Language_Name) = UPPER(@p_Language_Name);
BEGIN  
	SET @v_New_EEC_Id = 1;
	IF @p_Language_Name = 'English' 
		DELETE English_European_Countries;
	ELSE IF @p_Language_Name = 'French' 
		DELETE French_European_Countries;	 
	OPEN c_Get_Countries 
  
	FETCH NEXT FROM c_Get_Countries 
	INTO @v_Country_Name, @v_Country_Code, @v_Language_Category;
  
	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		IF @p_Language_Name = 'English' 
			INSERT INTO English_European_Countries (English_CL_Id, Country_Code, Country_Name, Language_Category)
			VALUES (@v_New_EEC_Id, @v_Country_Code, @v_Country_Name, @v_Language_Category);
		ELSE IF @p_Language_Name = 'French' 
			INSERT INTO French_European_Countries (French_CL_Id, Country_Code, Country_Name, Language_Category)
			VALUES (@v_New_EEC_Id, @v_Country_Code, @v_Country_Name, @v_Language_Category);		
		
		SET @v_New_EEC_Id = @v_New_EEC_Id + 1;

	FETCH NEXT FROM c_Get_Countries INTO @v_Country_Name, @v_Country_Code, @v_Language_Category;
	END
      
  CLOSE c_Get_Countries;
  
  DEALLOCATE c_Get_Countries;
END;
GO