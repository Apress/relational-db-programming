-- Listing 1-2: The design is just the first step
CREATE TABLE Invoices
(
    Invoice_Id INT NOT NULL,
    Supplier_Id INT NOT NULL,
    Invoice_Date DATE NOT NULL,
    CONSTRAINT PK_Invoices_Invoice_Id
    PRIMARY KEY (Invoice_Id)
);

ALTER TABLE Invoices ADD CONSTRAINT FK_Invoices_Suppliers
FOREIGN KEY (Supplier_Id) REFERENCES Suppliers (Supplier_Id);
CREATE TABLE Invoices_Details
(
    Invoice_Id INT NOT NULL,
    Current_Number INT NOT NULL,
    Quantity INT NOT NULL,
    Currency VARCHAR (30) NOT NULL,
    CONSTRAINT PK_Invoices_Details PRIMARY KEY (Invoice_Id, Current_Number),
	CONSTRAINT FK_Invoices_Invoices_Details FOREIGN KEY (Invoice_Id) 
	REFERENCES Invoices (Invoice_Id)
);
