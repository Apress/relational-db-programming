-- Listing 5-7 Full Data Transfer Holistic Style SQL Server
CREATE PROCEDURE Holistic_Full_Transf_Country
(
  @p_Language_Name VARCHAR(50)
)
AS
BEGIN
	DELETE English_European_Countries 
	WHERE @p_Language_Name = 'English';
	
	DELETE French_European_Countries 
	WHERE @p_Language_Name = 'French';
	
    INSERT INTO English_European_Countries (English_CL_Id, Country_Code, Country_Name, Language_Category)
	SELECT ROW_NUMBER() OVER (ORDER BY c.Country_Code, cl.Language_Category) AS English_CL_Id, 
	c.Country_Code, c.Country_Name, cl.Language_Category
	FROM Countries_Languages cl INNER JOIN Languages l 
		ON (l.Language_Id = cl.Language_Id)
	INNER JOIN Countries c 
		ON (c.Country_Id = cl.Country_Id) 
	WHERE l.Language_Name = @p_Language_Name AND @p_Language_Name = 'English';
	
    INSERT INTO French_European_Countries (French_CL_Id, Country_Code, Country_Name, Language_Category)
	SELECT ROW_NUMBER() OVER (ORDER BY c.Country_Code, cl.Language_Category) AS French_CL_Id, 
	c.Country_Code, c.Country_Name, cl.Language_Category
	FROM Countries_Languages cl INNER JOIN Languages l 
		ON (l.Language_Id = cl.Language_Id)
	INNER JOIN Countries c 
		ON (c.Country_Id = cl.Country_Id) 
	WHERE l.Language_Name = @p_Language_Name AND @p_Language_Name = 'French';	
END
GO