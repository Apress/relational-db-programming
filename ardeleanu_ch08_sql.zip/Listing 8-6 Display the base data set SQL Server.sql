-- Listing 8-6 Display the base data set SQL Server
SELECT c.Country_Name, cl.Language_Category, l.Language_Name
FROM Countries_Languages cl INNER JOIN Languages l 
	ON (l.Language_Id = cl.Language_Id)
INNER JOIN Countries c
	ON (c.Country_Id = cl.Country_Id) 
ORDER BY l.Language_Name, cl.Language_Category, c.Country_Name;