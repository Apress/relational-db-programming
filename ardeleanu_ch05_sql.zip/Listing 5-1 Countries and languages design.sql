-- Listing 5-1 Countries and languages design
CREATE TABLE Countries
(
	Country_Id INT CONSTRAINT NN_Country_Id NOT NULL,
	Country_Code VARCHAR(3) CONSTRAINT NN_Country_Code NOT NULL,
	Country_Name VARCHAR(50) CONSTRAINT NN_Country_Name NOT NULL,
	Continent VARCHAR(15) CONSTRAINT NN_Country_Continent NOT NULL,
	CONSTRAINT PK_Country_Id PRIMARY KEY (Country_Id),
	CONSTRAINT UQ_Country_Code UNIQUE (Country_Code),
	CONSTRAINT CK_Country_Continent 
	CHECK(Continent IN ('Europe', 'North America' ,'South America', 
					'Asia', 'Africa', 'Australia', 'Central America'))
);

CREATE TABLE Languages
(
	Language_Id INT CONSTRAINT NN_Language_Id NOT NULL,
	Language_Name VARCHAR(50) CONSTRAINT NN_Language_Name NOT NULL,
	CONSTRAINT PK_Language_Id PRIMARY KEY (Language_Id),
	CONSTRAINT UQ_Language_Name UNIQUE (Language_Name)
);

CREATE TABLE Countries_Languages
(
	CL_Id INT CONSTRAINT NN_CL_Id NOT NULL, 
	Language_Id INT CONSTRAINT NN_CL_Language_Id NOT NULL,
	Country_Id INT CONSTRAINT NN_CL_Country_Id NOT NULL,
	Language_Category VARCHAR(10) CONSTRAINT NN_CL_Category NOT NULL,
	Make_Flag INT, 
	CONSTRAINT PK_CL_Id PRIMARY KEY (CL_Id),
	CONSTRAINT UQ_Language_Country UNIQUE (Language_Id, Country_Id),
	CONSTRAINT CK_CL_Category CHECK (Language_Category IN ('MAIN', 'SECONDARY')),
	CONSTRAINT CK_CL_Make_Flag CHECK (Make_Flag IN (0, 1)),
	CONSTRAINT FK_CL_Countries FOREIGN KEY (Country_Id) REFERENCES Countries(Country_Id),
	CONSTRAINT FK_CL_Languages FOREIGN KEY (Language_Id) REFERENCES Languages (Language_Id)
);
-- Build an Oracle sequence too
CREATE SEQUENCE CL_Id_Seq;