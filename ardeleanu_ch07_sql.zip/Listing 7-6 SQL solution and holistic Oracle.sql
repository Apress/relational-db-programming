-- Listing 7-6 SQL solution and holistic Oracle
CREATE PROCEDURE Holistic_Full_Tr_Country_SQL
(
  p_Language_Name VARCHAR
)
AS
BEGIN
	DELETE Countries_Languages dest 
	WHERE EXISTS
	(
		SELECT 1 FROM Languages lang
		WHERE lang.Language_Name = p_Language_Name AND  p_Language_Name IN ('English', 'French')
		AND lang.Language_Id = dest.Language_Id
	)	
	OR EXISTS
	(
		SELECT 1 FROM Languages lang
		WHERE lang.Language_Name IN ('English', 'French') AND lang.Language_Name = 'Both'
		AND lang.Language_Id = dest.Language_Id
	);
	
	INSERT INTO Countries_Languages  (CL_Id, Country_Id, Language_Id, Language_Category)
	SELECT v_Max_CL_Id + RowNum AS CL_Id, Country_Id, Language_Id, Language_Category
	FROM
	(
		SELECT c.Country_Id, eec.Language_Category,
		(SELECT COALESCE(Max(CL_Id) , 0) FROM Countries_Languages) AS v_Max_CL_Id,
		(SELECT Language_Id FROM Languages WHERE Language_Name = 'English') AS Language_Id
		FROM English_European_Countries eec INNER JOIN Countries c ON (c.Country_Code = eec.Country_Code) 
		WHERE p_Language_Name IN ('English', 'Both')
		UNION
		SELECT c.Country_Id, eec.Language_Category,
		(SELECT COALESCE(Max(CL_Id) , 0)   FROM Countries_Languages) AS v_Max_CL_Id,
		(SELECT Language_Id FROM Languages WHERE Language_Name = 'French') AS Language_Id
		FROM French_European_Countries eec INNER JOIN Countries c ON (c.Country_Code = eec.Country_Code)
		WHERE p_Language_Name IN ('French', 'Both')	
	) lf;
	COMMIT;
  
END Holistic_Full_Tr_Country_SQL;
/