-- Listing 8-5 Display a list atomically SQL Server 
CREATE PROCEDURE Atomic_List_Of_Countries
AS
	DECLARE @v_Country_Name NVARCHAR(50);
	DECLARE @v_Language_Category NVARCHAR(10); 
	DECLARE @v_Language_Name NVARCHAR(50);
	DECLARE @v_Language_Id INT;
	DECLARE @v_List_Of_Countries_Main NVARCHAR(4000);
	DECLARE @v_List_Of_Countries_Sec NVARCHAR(4000);
	DECLARE @v_Previous_Language_Name NVARCHAR(50);	
	DECLARE c_Get_Languages CURSOR FOR
	SELECT l.Language_Id, l.Language_Name
	FROM Languages l
	WHERE EXISTS
	(
		SELECT 1 FROM Countries_Languages cl
		WHERE cl.Language_Id = l.Language_Id
	)
	ORDER BY 2;
BEGIN
	CREATE TABLE #List_Of_Countries (Language_Name NVARCHAR(50), List_Of_Countries_Main NVARCHAR(4000), List_Of_Countries_Sec NVARCHAR(4000));
	
	OPEN c_Get_Languages;
	
	FETCH NEXT FROM c_Get_Languages 
	INTO @v_Language_Id, @v_Language_Name;
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @v_List_Of_Countries_Main 	= '';
		SET @v_List_Of_Countries_Sec 	= '';
		
		DECLARE c_Get_Countries CURSOR FOR
		SELECT c.Country_Name, cl.Language_Category
		FROM Countries_Languages cl INNER JOIN Countries c
			ON (c.Country_Id = cl.Country_Id) 
		WHERE cl.Language_Id = @v_Language_Id
		ORDER BY cl.Language_Category, c.Country_Name;	

		OPEN c_Get_Countries;
 
		FETCH NEXT FROM c_Get_Countries 
		INTO @v_Country_Name, @v_Language_Category;	

		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @v_Language_Category = 'MAIN'
				SELECT @v_List_Of_Countries_Main = @v_List_Of_Countries_Main + @v_Country_Name  + ','
			ELSE
				SELECT @v_List_Of_Countries_Sec = @v_List_Of_Countries_Sec + @v_Country_Name  + ','
			
			FETCH NEXT FROM c_Get_Countries 
			INTO @v_Country_Name, @v_Language_Category;	
		END
		
		CLOSE c_Get_Countries;
		
		DEALLOCATE c_Get_Countries;
		
		IF LEN(@v_List_Of_Countries_Main) > 1
			SET @v_List_Of_Countries_Main = SUBSTRING(@v_List_Of_Countries_Main, 1, LEN(@v_List_Of_Countries_Main) - 1);
		
		IF LEN(@v_List_Of_Countries_Sec) > 1
			SET @v_List_Of_Countries_Sec = SUBSTRING(@v_List_Of_Countries_Sec, 1, LEN(@v_List_Of_Countries_Sec) - 1);
		
		INSERT INTO #List_Of_Countries (Language_Name,  List_Of_Countries_Main, List_Of_Countries_Sec)
		VALUES (@v_Language_Name, @v_List_Of_Countries_Main, @v_List_Of_Countries_Sec);
		
		FETCH NEXT FROM c_Get_Languages 
		INTO @v_Language_Id, @v_Language_Name;
	END
	
	CLOSE c_Get_Languages
	
	DEALLOCATE c_Get_Languages;
	
	SELECT * FROM #List_Of_Countries
	
	DROP TABLE #List_Of_Countries
END
GO
